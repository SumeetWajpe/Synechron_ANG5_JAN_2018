import { Component } from "@angular/core";
import { ProductService } from "./product.service";

@Component({
    selector:`useprodserv`,
    template:`
    
    <div style="width:500px;border:2px solid red;border-radius:10px;padding:20px;margin:20px;">
    <h1>Product Service Component</h1>
    <input type="text" [(ngModel)]="productToBeAdded" /> {{productReceived}}  <br/>
    <input type="button" (click)="AddProduct()" value="Add Product>>" class="btn btn-primary" />
    <input type="button" (click)="GetProduct()" value="Get Random Product" class="btn btn-danger" />
    
</div> 
    
    `,
    // providers:[ProductService]
})
export class UseProductServComp{
    productToBeAdded:string= "";
    productReceived:string="";
        constructor(private servObj:ProductService){
                 console.log(this.servObj.getRandomProduct());
        }

        AddProduct(){
            this.servObj.insertNewProduct(this.productToBeAdded);
        }
    
        GetProduct(){
          this.productReceived =   this.servObj.getRandomProduct();
        }
}