import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {FormsModule} from '@angular/forms'
import {HttpModule} from '@angular/http';
import { AppComponent }  from './app.component';


import {CourseComponent} from './course.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { StockPipe } from './custom.pipe';
import { UseProductServComp } from './useproductservice.component';
import {ProductService} from './product.service'
import { PostsComponent } from './posts.component';
import {Routes,RouterModule} from '@angular/router';
import { PostDetailComponent } from './postdetail.component';



const routes:Routes=[
  {path:'posts',component:PostsComponent},
  {path:'view/:id',component:PostDetailComponent},
  {path:'cart',component:ShoppingCartComponent},
  {path:'',redirectTo:'/cart',pathMatch:'full'},  
  {path:'**',redirectTo:'/posts',pathMatch:'full'}
  
];


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,PostDetailComponent,PostsComponent,UseProductServComp,CourseComponent,StockPipe,ShoppingCartComponent,ProductComponent ],
  bootstrap:    [ AppComponent ],
  providers:[ProductService]
})
export class AppModule { }
