import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`
  
  <a routerLink="/posts" class="btn btn-primary">Posts</a>
  <a routerLink="/cart" class="btn btn-primary">Cart</a>
  


  <router-outlet></router-outlet>
  
  `
  // template:`
  // <useprodserv></useprodserv>
  // <useprodserv></useprodserv>
  
  // `
  // template:`
  //   <shoppingcart></shoppingcart>
  // `
  // template:`<h1> List Of Courses</h1>
  
  // <!-- <ul>
  // <li *ngFor="let course of courses">{{course.title}}</li>
  // </ul> -->

  // <div>
  // <p *ngFor="let c of courses">
  //   <course [details]="c"></course>
  // </p>
  // </div>  
  // `
  //------------------------------------------
//   template: `
  
//   <img src="{{imageUrl}}" height="200px" width="200px" />
//   <img [src]="imageUrl" height="200px" width="200px" />

//   <course [details]="course1name" ></course>
//   <course [details]="course2name"></course>
//   <course [details]="course3name"></course>`,
 })
export class AppComponent  { 

  imageUrl:string= "https://christianliebel.com/wp-content/uploads/2016/02/Angular2.png"

  courses = [ {title: 'Backbone',price:4000},
   {title: 'Node',price:3000},
  {title: 'React',price:5000}];
  
  
 }
