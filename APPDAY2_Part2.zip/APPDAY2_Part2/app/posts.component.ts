import {Component} from '@angular/core';
import {PostService} from './posts.service';


@Component({
    selector:`posts`,
    template:`<h1> All Posts ! </h1>
    
<div>

<ul>
<li *ngFor="let post of receivedPosts"> <a [routerLink]="['/view',post.id]"> {{post.title}} </a></li>
</ul>
</div>

    `,
    providers:[PostService]
})
export class PostsComponent{

    receivedPosts:any;
    // constructor(private servObj:PostService){
    //         this.servObj.getPosts((dataFromService:any)=>{   
    //         this.receivedPosts  = dataFromService;
    //         });
    // }

    constructor(private servObj:PostService){
      let aPromise =  this.servObj.getPosts();
      aPromise.then(
            (response)=>{
                        this.receivedPosts = response.json();
            },
            (err)=>{
                    console.log(err)
            }

      )
}
}

