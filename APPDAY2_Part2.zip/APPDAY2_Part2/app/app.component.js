"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.imageUrl = "https://christianliebel.com/wp-content/uploads/2016/02/Angular2.png";
        this.courses = [{ title: 'Backbone', price: 4000 },
            { title: 'Node', price: 3000 },
            { title: 'React', price: 5000 }];
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n  \n  <a routerLink=\"/posts\" class=\"btn btn-primary\">Posts</a>\n  <a routerLink=\"/cart\" class=\"btn btn-primary\">Cart</a>\n  \n\n\n  <router-outlet></router-outlet>\n  \n  "
        // template:`
        // <useprodserv></useprodserv>
        // <useprodserv></useprodserv>
        // `
        // template:`
        //   <shoppingcart></shoppingcart>
        // `
        // template:`<h1> List Of Courses</h1>
        // <!-- <ul>
        // <li *ngFor="let course of courses">{{course.title}}</li>
        // </ul> -->
        // <div>
        // <p *ngFor="let c of courses">
        //   <course [details]="c"></course>
        // </p>
        // </div>  
        // `
        //------------------------------------------
        //   template: `
        //   <img src="{{imageUrl}}" height="200px" width="200px" />
        //   <img [src]="imageUrl" height="200px" width="200px" />
        //   <course [details]="course1name" ></course>
        //   <course [details]="course2name"></course>
        //   <course [details]="course3name"></course>`,
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map