"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var product_service_1 = require("./product.service");
var UseProductServComp = (function () {
    function UseProductServComp(servObj) {
        this.servObj = servObj;
        this.productToBeAdded = "";
        this.productReceived = "";
        console.log(this.servObj.getRandomProduct());
    }
    UseProductServComp.prototype.AddProduct = function () {
        this.servObj.insertNewProduct(this.productToBeAdded);
    };
    UseProductServComp.prototype.GetProduct = function () {
        this.productReceived = this.servObj.getRandomProduct();
    };
    return UseProductServComp;
}());
UseProductServComp = __decorate([
    core_1.Component({
        selector: "useprodserv",
        template: "\n    \n    <div style=\"width:500px;border:2px solid red;border-radius:10px;padding:20px;margin:20px;\">\n    <h1>Product Service Component</h1>\n    <input type=\"text\" [(ngModel)]=\"productToBeAdded\" /> {{productReceived}}  <br/>\n    <input type=\"button\" (click)=\"AddProduct()\" value=\"Add Product>>\" class=\"btn btn-primary\" />\n    <input type=\"button\" (click)=\"GetProduct()\" value=\"Get Random Product\" class=\"btn btn-danger\" />\n    \n</div> \n    \n    ",
    }),
    __metadata("design:paramtypes", [product_service_1.ProductService])
], UseProductServComp);
exports.UseProductServComp = UseProductServComp;
//# sourceMappingURL=useproductservice.component.js.map