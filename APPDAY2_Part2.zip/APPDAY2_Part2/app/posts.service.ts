import {Http} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostService{


        // make ajax request ! Http
        constructor(private httpObj:Http){

        }

        // getPosts(callBackFunc:any){
        //     this.httpObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(response){
        //                 callBackFunc(response.json());// return data to component
        //     })
        // }

        getPosts(){
          return  this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
        }

}